package com.aimtrix.app.engine;

import android.content.Context;
import android.util.Log;

import com.aimtrix.app.shizuku.ShizukuManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GamingOptimizer {

    private static final String TAG = "AIMTRIX_Engine";
    private static final String FREE_FIRE_PKG = "com.dts.freefireth";
    private static final String FREE_FIRE_MAX_PKG = "com.dts.freefiremax";

    private final Context context;
    private final ShizukuManager shizuku;
    private final EngineConfig config;

    // Engine status tracking
    private boolean smartDpiActive = false;
    private boolean fpsBoostActive = false;
    private boolean surfaceTuningActive = false;
    private boolean sensitivityActive = false;
    private int currentFps = 0;

    public GamingOptimizer(Context context) {
        this.context = context;
        this.shizuku = ShizukuManager.getInstance();
        this.config = new EngineConfig(context);
    }

    // ─── SMART DPI ENGINE ───────────────────────────────────────────────────────
    public boolean applySmartDpi() {
        Log.d(TAG, "Applying Smart DPI & Resolution...");
        List<String> commands = Arrays.asList(
            "wm size 1440x3200",
            "wm density adaptive",
            "settings put system window_animation_scale 0.5",
            "settings put system transition_animation_scale 0.5",
            "settings put system animator_duration_scale 0.5"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        smartDpiActive = success;
        Log.d(TAG, "Smart DPI: " + (success ? "ACTIVE" : "FAILED"));
        return success;
    }

    public boolean revertSmartDpi() {
        List<String> commands = Arrays.asList(
            "wm size reset",
            "wm density reset",
            "settings put system window_animation_scale 1.0",
            "settings put system transition_animation_scale 1.0",
            "settings put system animator_duration_scale 1.0"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        smartDpiActive = !success;
        return success;
    }

    // ─── FPS STABILIZER ─────────────────────────────────────────────────────────
    public boolean applyFpsBoost() {
        Log.d(TAG, "Applying FPS Boost...");
        List<String> commands = Arrays.asList(
            "service call SurfaceFlinger 1008 i32 1",
            "setprop debug.sf.latch_unsignaled 1",
            "setprop debug.sf.disable_backpressure 1",
            "setprop debug.sf.hw 1",
            "setprop debug.egl.hw 1",
            "setprop debug.performance.tuning 1",
            "setprop video.accelerate.hw 1",
            "setprop debug.sf.recomputecrop 0",
            "setprop persist.sys.ui.hw 1"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        fpsBoostActive = success;
        Log.d(TAG, "FPS Boost: " + (success ? "ACTIVE" : "FAILED"));
        return success;
    }

    public boolean revertFpsBoost() {
        List<String> commands = Arrays.asList(
            "setprop debug.sf.latch_unsignaled 0",
            "setprop debug.sf.disable_backpressure 0"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        fpsBoostActive = !success;
        return success;
    }

    // ─── SURFACE TUNING ──────────────────────────────────────────────────────────
    public boolean applySurfaceTuning() {
        Log.d(TAG, "Applying Surface Tuning...");
        List<String> commands = Arrays.asList(
            "setprop debug.sf.enable_gl_backpressure 0",
            "setprop debug.sf.enable_egl_image_tracker 0",
            "setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3",
            "setprop debug.hwui.renderer opengl",
            "setprop debug.hwui.use_gpu_pixel_buffers true",
            "setprop debug.hwui.profile false",
            "setprop debug.hwui.overdraw false"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        surfaceTuningActive = success;
        return success;
    }

    // ─── SENSITIVITY ENGINE ──────────────────────────────────────────────────────
    public boolean applySensitivityEngine() {
        Log.d(TAG, "Applying Sensitivity Engine...");
        List<String> commands = Arrays.asList(
            "setprop touch.pressure.scale 0.001",
            "setprop ro.input.resample false",
            "setprop ro.input.noresample 1",
            "settings put system pointer_speed 0",
            "setprop debug.input.latency 0",
            "setprop touch.deviceType touchScreen",
            "setprop touch.orientationCalibration default"
        );
        boolean success = shizuku.executeMultipleCommands(commands);
        sensitivityActive = success;
        return success;
    }

    // ─── CACHE FLUSH ─────────────────────────────────────────────────────────────
    public boolean flushCache() {
        Log.d(TAG, "Flushing cache & RAM...");
        List<String> commands = Arrays.asList(
            "am kill-all",
            "sync",
            "echo 3 > /proc/sys/vm/drop_caches",
            "am compact all"
        );
        return shizuku.executeMultipleCommands(commands);
    }

    // ─── GAME DETECTION ──────────────────────────────────────────────────────────
    public boolean isFreefireRunning() {
        String pid = shizuku.executeCommandWithOutput("pidof " + FREE_FIRE_PKG);
        if (pid == null || pid.isEmpty() || pid.equals("SHIZUKU_UNAVAILABLE")) {
            pid = shizuku.executeCommandWithOutput("pidof " + FREE_FIRE_MAX_PKG);
        }
        return pid != null && !pid.isEmpty() && !pid.equals("SHIZUKU_UNAVAILABLE") && !pid.startsWith("ERROR");
    }

    public String getTopActivity() {
        String result = shizuku.executeCommandWithOutput(
            "dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp'"
        );
        return result != null ? result : "";
    }

    // ─── APPLY ALL TWEAKS ────────────────────────────────────────────────────────
    public void applyAllOptimizations(EngineConfig cfg) {
        if (cfg.isSmartDpiEnabled()) applySmartDpi();
        if (cfg.isFpsBoostEnabled()) applyFpsBoost();
        if (cfg.isSurfaceTuningEnabled()) applySurfaceTuning();
        if (cfg.isSensitivityEnabled()) applySensitivityEngine();
    }

    public void revertAllOptimizations() {
        revertSmartDpi();
        revertFpsBoost();
    }

    // ─── STATUS GETTERS ──────────────────────────────────────────────────────────
    public boolean isSmartDpiActive() { return smartDpiActive; }
    public boolean isFpsBoostActive() { return fpsBoostActive; }
    public boolean isSurfaceTuningActive() { return surfaceTuningActive; }
    public boolean isSensitivityActive() { return sensitivityActive; }
}
