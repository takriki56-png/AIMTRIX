package com.aimtrix.app.shizuku;

import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

public class ShizukuManager {

    private static final String TAG = "AIMTRIX_Shizuku";
    private static ShizukuManager instance;
    
    private boolean shizukuAvailable = false;
    private OnShizukuStateChangeListener stateListener;

    public interface OnShizukuStateChangeListener {
        void onStateChanged(boolean available);
    }

    public interface CommandCallback {
        void onResult(boolean success, String output);
    }

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = () -> {
        Log.d(TAG, "Shizuku binder received");
        shizukuAvailable = true;
        if (stateListener != null) stateListener.onStateChanged(true);
    };

    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> {
        Log.d(TAG, "Shizuku binder dead");
        shizukuAvailable = false;
        if (stateListener != null) stateListener.onStateChanged(false);
    };

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener = 
        (requestCode, grantResult) -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                shizukuAvailable = true;
                if (stateListener != null) stateListener.onStateChanged(true);
            }
        };

    public static ShizukuManager getInstance() {
        if (instance == null) {
            instance = new ShizukuManager();
        }
        return instance;
    }

    public void init() {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);
    }

    public void destroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
    }

    public void setStateListener(OnShizukuStateChangeListener listener) {
        this.stateListener = listener;
    }

    public boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    public void requestPermission() {
        try {
            Shizuku.requestPermission(0x1337);
        } catch (Exception e) {
            Log.e(TAG, "Failed to request permission: " + e.getMessage());
        }
    }

    public boolean executeCommand(String command) {
        if (!isShizukuAvailable() || !hasPermission()) {
            Log.w(TAG, "Shizuku not available or no permission");
            return false;
        }
        
        try {
            String[] args = new String[]{"sh", "-c", command};
            Shizuku.UserServiceArgs serviceArgs = null;
            
            // Execute via Shizuku newProcess
            ShizukuRemoteProcess process = Shizuku.newProcess(args, null, null);
            int exitCode = process.waitFor();
            
            Log.d(TAG, "Command executed: " + command + " | Exit: " + exitCode);
            return exitCode == 0;
        } catch (Exception e) {
            Log.e(TAG, "Command failed: " + command + " | " + e.getMessage());
            return false;
        }
    }

    public String executeCommandWithOutput(String command) {
        if (!isShizukuAvailable() || !hasPermission()) {
            return "SHIZUKU_UNAVAILABLE";
        }
        
        StringBuilder output = new StringBuilder();
        try {
            String[] args = new String[]{"sh", "-c", command};
            ShizukuRemoteProcess process = Shizuku.newProcess(args, null, null);
            
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream())
            );
            
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            process.waitFor();
            reader.close();
            
        } catch (Exception e) {
            Log.e(TAG, "Command with output failed: " + e.getMessage());
            return "ERROR: " + e.getMessage();
        }
        
        return output.toString().trim();
    }

    public boolean executeMultipleCommands(List<String> commands) {
        boolean allSuccess = true;
        for (String cmd : commands) {
            boolean result = executeCommand(cmd);
            if (!result) allSuccess = false;
        }
        return allSuccess;
    }
}
