package com.aimtrix.app.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.aimtrix.app.AimtrixApp;
import com.aimtrix.app.R;
import com.aimtrix.app.engine.EngineConfig;
import com.aimtrix.app.engine.GamingOptimizer;
import com.aimtrix.app.shizuku.ShizukuManager;
import com.aimtrix.app.ui.MainActivity;

public class AimtrixEngineService extends Service {

    private static final String TAG = "AIMTRIX_Service";
    private static final int NOTIFICATION_ID = 1001;
    private static final long MONITOR_INTERVAL = 5000; // 5 seconds

    public static final String ACTION_START = "START_ENGINE";
    public static final String ACTION_STOP = "STOP_ENGINE";
    public static final String ACTION_CACHE_FLUSH = "CACHE_FLUSH";
    public static final String ACTION_APPLY_ALL = "APPLY_ALL";

    // Broadcast actions for UI update
    public static final String BROADCAST_STATUS = "com.aimtrix.STATUS_UPDATE";
    public static final String EXTRA_FPS = "fps";
    public static final String EXTRA_GAME_DETECTED = "game_detected";
    public static final String EXTRA_SHIZUKU_OK = "shizuku_ok";

    private GamingOptimizer optimizer;
    private EngineConfig config;
    private Handler handler;
    private boolean isRunning = false;

    private final Runnable monitorTask = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            boolean shizukuOk = ShizukuManager.getInstance().isShizukuAvailable()
                && ShizukuManager.getInstance().hasPermission();
            boolean gameDetected = false;

            if (shizukuOk) {
                gameDetected = optimizer.isFreefireRunning();
                
                // Auto-apply optimizations when game detected
                if (gameDetected && config.isAutoGameModeEnabled()) {
                    optimizer.applyAllOptimizations(config);
                    if (config.isCacheFlushEnabled()) {
                        optimizer.flushCache();
                    }
                }
            }

            // Broadcast status update
            Intent broadcast = new Intent(BROADCAST_STATUS);
            broadcast.putExtra(EXTRA_SHIZUKU_OK, shizukuOk);
            broadcast.putExtra(EXTRA_GAME_DETECTED, gameDetected);
            broadcast.putExtra(EXTRA_FPS, estimateFps());
            sendBroadcast(broadcast);

            updateNotification(shizukuOk, gameDetected);
            handler.postDelayed(this, MONITOR_INTERVAL);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        config = new EngineConfig(this);
        optimizer = new GamingOptimizer(this);
        ShizukuManager.getInstance().init();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (action == null) action = ACTION_START;

            switch (action) {
                case ACTION_START:
                    startEngine();
                    break;
                case ACTION_STOP:
                    stopEngine();
                    return START_NOT_STICKY;
                case ACTION_CACHE_FLUSH:
                    optimizer.flushCache();
                    break;
                case ACTION_APPLY_ALL:
                    optimizer.applyAllOptimizations(config);
                    break;
            }
        } else {
            startEngine();
        }
        return START_STICKY;
    }

    private void startEngine() {
        Log.d(TAG, "Starting AIMTRIX Engine...");
        isRunning = true;
        startForeground(NOTIFICATION_ID, buildNotification("Engine Running", "Monitoring game activity..."));
        handler.post(monitorTask);
    }

    private void stopEngine() {
        Log.d(TAG, "Stopping AIMTRIX Engine...");
        isRunning = false;
        handler.removeCallbacks(monitorTask);
        optimizer.revertAllOptimizations();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Notification buildNotification(String title, String text) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, AimtrixEngineService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, AimtrixApp.CHANNEL_ENGINE)
            .setContentTitle("⚡ " + title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_stop, "Stop Engine", stopPending)
            .setColor(0xFF00FF41)
            .build();
    }

    private void updateNotification(boolean shizukuOk, boolean gameDetected) {
        String status = shizukuOk ? "🟢 Engine Active" : "🔴 Shizuku Required";
        String detail = gameDetected ? "🎮 Free Fire Detected - Optimizing..." : "Monitoring for games...";

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(status, detail));
    }

    private int estimateFps() {
        // Simulated FPS - in real impl, use Choreographer.FrameCallback
        return 60 + (int)(Math.random() * 4) - 2;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        handler.removeCallbacks(monitorTask);
        ShizukuManager.getInstance().destroy();
    }
}
