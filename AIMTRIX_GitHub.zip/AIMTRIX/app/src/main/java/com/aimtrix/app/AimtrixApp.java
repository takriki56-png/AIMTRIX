package com.aimtrix.app;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class AimtrixApp extends Application {

    public static final String CHANNEL_ENGINE = "aimtrix_engine";
    public static final String CHANNEL_OVERLAY = "aimtrix_overlay";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        NotificationManager manager = getSystemService(NotificationManager.class);

        NotificationChannel engineChannel = new NotificationChannel(
            CHANNEL_ENGINE,
            "AIMTRIX Engine",
            NotificationManager.IMPORTANCE_LOW
        );
        engineChannel.setDescription("Gaming optimization engine");
        engineChannel.setShowBadge(false);

        NotificationChannel overlayChannel = new NotificationChannel(
            CHANNEL_OVERLAY,
            "AIMTRIX Overlay",
            NotificationManager.IMPORTANCE_LOW
        );
        overlayChannel.setDescription("ROG-style gaming overlay");
        overlayChannel.setShowBadge(false);

        manager.createNotificationChannel(engineChannel);
        manager.createNotificationChannel(overlayChannel);
    }
}
