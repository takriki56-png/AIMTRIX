package com.aimtrix.app.engine;

import android.content.Context;
import android.content.SharedPreferences;

public class EngineConfig {
    private static final String PREFS_NAME = "aimtrix_config";
    
    private static final String KEY_SMART_DPI = "smart_dpi";
    private static final String KEY_FPS_BOOST = "fps_boost";
    private static final String KEY_SURFACE_TUNING = "surface_tuning";
    private static final String KEY_SENSITIVITY = "sensitivity";
    private static final String KEY_CACHE_FLUSH = "cache_flush";
    private static final String KEY_ROG_OVERLAY = "rog_overlay";
    private static final String KEY_VIP_MODE = "vip_mode";
    private static final String KEY_AUTO_GAME_MODE = "auto_game_mode";
    private static final String KEY_PERF_GRAPH = "perf_graph";
    
    private final SharedPreferences prefs;
    
    public EngineConfig(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    public boolean isSmartDpiEnabled() { return prefs.getBoolean(KEY_SMART_DPI, false); }
    public boolean isFpsBoostEnabled() { return prefs.getBoolean(KEY_FPS_BOOST, false); }
    public boolean isSurfaceTuningEnabled() { return prefs.getBoolean(KEY_SURFACE_TUNING, false); }
    public boolean isSensitivityEnabled() { return prefs.getBoolean(KEY_SENSITIVITY, false); }
    public boolean isCacheFlushEnabled() { return prefs.getBoolean(KEY_CACHE_FLUSH, false); }
    public boolean isRogOverlayEnabled() { return prefs.getBoolean(KEY_ROG_OVERLAY, false); }
    public boolean isVipModeEnabled() { return prefs.getBoolean(KEY_VIP_MODE, false); }
    public boolean isAutoGameModeEnabled() { return prefs.getBoolean(KEY_AUTO_GAME_MODE, false); }
    public boolean isPerfGraphEnabled() { return prefs.getBoolean(KEY_PERF_GRAPH, false); }
    
    public void setSmartDpi(boolean v) { prefs.edit().putBoolean(KEY_SMART_DPI, v).apply(); }
    public void setFpsBoost(boolean v) { prefs.edit().putBoolean(KEY_FPS_BOOST, v).apply(); }
    public void setSurfaceTuning(boolean v) { prefs.edit().putBoolean(KEY_SURFACE_TUNING, v).apply(); }
    public void setSensitivity(boolean v) { prefs.edit().putBoolean(KEY_SENSITIVITY, v).apply(); }
    public void setCacheFlush(boolean v) { prefs.edit().putBoolean(KEY_CACHE_FLUSH, v).apply(); }
    public void setRogOverlay(boolean v) { prefs.edit().putBoolean(KEY_ROG_OVERLAY, v).apply(); }
    public void setVipMode(boolean v) { prefs.edit().putBoolean(KEY_VIP_MODE, v).apply(); }
    public void setAutoGameMode(boolean v) { prefs.edit().putBoolean(KEY_AUTO_GAME_MODE, v).apply(); }
    public void setPerfGraph(boolean v) { prefs.edit().putBoolean(KEY_PERF_GRAPH, v).apply(); }
}
