package com.aimtrix.app.ui;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.materialswitch.widget.MaterialSwitch;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.aimtrix.app.R;
import com.aimtrix.app.engine.EngineConfig;
import com.aimtrix.app.engine.GamingOptimizer;
import com.aimtrix.app.service.AimtrixEngineService;
import com.aimtrix.app.service.OverlayService;
import com.aimtrix.app.shizuku.ShizukuManager;

public class MainActivity extends AppCompatActivity {

    private EngineConfig config;
    private GamingOptimizer optimizer;
    private ShizukuManager shizuku;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean engineRunning = false;

    // UI elements
    private TextView tvShizukuStatus, tvEngineStatus, tvFpsValue, tvGameStatus;
    private MaterialSwitch swSmartDpi, swFpsBoost, swSurface, swSensitivity, swCache, swOverlay;
    private MaterialSwitch swVip, swAutoGame, swPerfGraph;
    private MaterialButton btnEngineToggle, btnCacheFlush;
    private View dotShizuku, dotEngine;
    private MaterialCardView cardShizuku;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean shizukuOk = intent.getBooleanExtra(AimtrixEngineService.EXTRA_SHIZUKU_OK, false);
            boolean gameDetected = intent.getBooleanExtra(AimtrixEngineService.EXTRA_GAME_DETECTED, false);
            int fps = intent.getIntExtra(AimtrixEngineService.EXTRA_FPS, 0);
            updateStatusUI(shizukuOk, gameDetected, fps);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        config = new EngineConfig(this);
        optimizer = new GamingOptimizer(this);
        shizuku = ShizukuManager.getInstance();
        shizuku.init();

        initViews();
        setupSwitches();
        setupButtons();
        setupShizukuListener();
        checkOverlayPermission();
    }

    private void initViews() {
        tvShizukuStatus = findViewById(R.id.tv_shizuku_status);
        tvEngineStatus = findViewById(R.id.tv_engine_status);
        tvFpsValue = findViewById(R.id.tv_fps_value);
        tvGameStatus = findViewById(R.id.tv_game_status);
        dotShizuku = findViewById(R.id.dot_shizuku);
        dotEngine = findViewById(R.id.dot_engine);
        cardShizuku = findViewById(R.id.card_shizuku);

        swSmartDpi = findViewById(R.id.sw_smart_dpi);
        swFpsBoost = findViewById(R.id.sw_fps_boost);
        swSurface = findViewById(R.id.sw_surface);
        swSensitivity = findViewById(R.id.sw_sensitivity);
        swCache = findViewById(R.id.sw_cache);
        swOverlay = findViewById(R.id.sw_overlay);
        swVip = findViewById(R.id.sw_vip);
        swAutoGame = findViewById(R.id.sw_auto_game);
        swPerfGraph = findViewById(R.id.sw_perf_graph);

        btnEngineToggle = findViewById(R.id.btn_engine_toggle);
        btnCacheFlush = findViewById(R.id.btn_cache_flush);

        // Load saved states
        swSmartDpi.setChecked(config.isSmartDpiEnabled());
        swFpsBoost.setChecked(config.isFpsBoostEnabled());
        swSurface.setChecked(config.isSurfaceTuningEnabled());
        swSensitivity.setChecked(config.isSensitivityEnabled());
        swCache.setChecked(config.isCacheFlushEnabled());
        swOverlay.setChecked(config.isRogOverlayEnabled());
        swVip.setChecked(config.isVipModeEnabled());
        swAutoGame.setChecked(config.isAutoGameModeEnabled());
        swPerfGraph.setChecked(config.isPerfGraphEnabled());
    }

    private void setupSwitches() {
        swSmartDpi.setOnCheckedChangeListener((b, checked) -> {
            config.setSmartDpi(checked);
            if (checked && requireShizuku()) {
                new Thread(() -> {
                    boolean ok = optimizer.applySmartDpi();
                    runOnUiThread(() -> toast(ok ? "✅ Smart DPI Applied" : "❌ DPI Failed"));
                }).start();
            }
        });

        swFpsBoost.setOnCheckedChangeListener((b, checked) -> {
            config.setFpsBoost(checked);
            if (checked && requireShizuku()) {
                new Thread(() -> {
                    boolean ok = optimizer.applyFpsBoost();
                    runOnUiThread(() -> toast(ok ? "✅ FPS Boost Applied" : "❌ FPS Boost Failed"));
                }).start();
            } else if (!checked) {
                new Thread(optimizer::revertFpsBoost).start();
            }
        });

        swSurface.setOnCheckedChangeListener((b, checked) -> {
            config.setSurfaceTuning(checked);
            if (checked && requireShizuku()) {
                new Thread(() -> {
                    boolean ok = optimizer.applySurfaceTuning();
                    runOnUiThread(() -> toast(ok ? "✅ Surface Tuning Active" : "❌ Surface Tuning Failed"));
                }).start();
            }
        });

        swSensitivity.setOnCheckedChangeListener((b, checked) -> {
            config.setSensitivity(checked);
            if (checked && requireShizuku()) {
                new Thread(() -> {
                    boolean ok = optimizer.applySensitivityEngine();
                    runOnUiThread(() -> toast(ok ? "✅ Sensitivity Calibrated" : "❌ Sensitivity Failed"));
                }).start();
            }
        });

        swCache.setOnCheckedChangeListener((b, checked) -> config.setCacheFlush(checked));

        swOverlay.setOnCheckedChangeListener((b, checked) -> {
            config.setRogOverlay(checked);
            if (checked) {
                if (Settings.canDrawOverlays(this)) {
                    startOverlayService();
                } else {
                    swOverlay.setChecked(false);
                    requestOverlayPermission();
                }
            } else {
                stopService(new Intent(this, OverlayService.class));
            }
        });

        swVip.setOnCheckedChangeListener((b, checked) -> {
            config.setVipMode(checked);
            if (checked) toast("🔐 VIP Mode Activated");
        });

        swAutoGame.setOnCheckedChangeListener((b, checked) -> {
            config.setAutoGameMode(checked);
            if (checked) toast("🎮 Auto Game Mode: ON — Will optimize when FF detected");
        });

        swPerfGraph.setOnCheckedChangeListener((b, checked) -> config.setPerfGraph(checked));
    }

    private void setupButtons() {
        btnEngineToggle.setOnClickListener(v -> toggleEngine());
        btnCacheFlush.setOnClickListener(v -> {
            if (!requireShizuku()) return;
            new Thread(() -> {
                optimizer.flushCache();
                runOnUiThread(() -> toast("🧹 RAM Flushed!"));
            }).start();
        });

        // Shizuku card click to request permission
        cardShizuku.setOnClickListener(v -> {
            if (!shizuku.isShizukuAvailable()) {
                showShizukuGuide();
            } else if (!shizuku.hasPermission()) {
                shizuku.requestPermission();
            }
        });
    }

    private void setupShizukuListener() {
        shizuku.setStateListener(available -> runOnUiThread(() -> {
            if (available && shizuku.hasPermission()) {
                updateShizukuStatus(true);
            } else if (available) {
                shizuku.requestPermission();
            } else {
                updateShizukuStatus(false);
            }
        }));

        // Initial check
        boolean ok = shizuku.isShizukuAvailable() && shizuku.hasPermission();
        updateShizukuStatus(ok);
    }

    private void updateShizukuStatus(boolean active) {
        if (active) {
            tvShizukuStatus.setText("SHIZUKU CONNECTED");
            tvShizukuStatus.setTextColor(getColor(R.color.color_green));
            dotShizuku.setBackgroundResource(R.drawable.dot_green);
        } else {
            tvShizukuStatus.setText("SHIZUKU OFFLINE");
            tvShizukuStatus.setTextColor(getColor(R.color.color_red));
            dotShizuku.setBackgroundResource(R.drawable.dot_red);
            blinkView(dotShizuku);
        }
    }

    private void updateStatusUI(boolean shizukuOk, boolean gameDetected, int fps) {
        updateShizukuStatus(shizukuOk);
        tvFpsValue.setText(fps + "");
        tvGameStatus.setText(gameDetected ? "🎮 FREE FIRE ACTIVE" : "IDLE");
        tvGameStatus.setTextColor(getColor(gameDetected ? R.color.color_green : R.color.color_dim));
    }

    private void toggleEngine() {
        if (!engineRunning) {
            Intent intent = new Intent(this, AimtrixEngineService.class);
            intent.setAction(AimtrixEngineService.ACTION_START);
            startForegroundService(intent);
            engineRunning = true;
            btnEngineToggle.setText("⏹ STOP ENGINE");
            btnEngineToggle.setBackgroundColor(getColor(R.color.color_red));
            tvEngineStatus.setText("ENGINE RUNNING");
            tvEngineStatus.setTextColor(getColor(R.color.color_green));
            dotEngine.setBackgroundResource(R.drawable.dot_green);
        } else {
            Intent intent = new Intent(this, AimtrixEngineService.class);
            intent.setAction(AimtrixEngineService.ACTION_STOP);
            startService(intent);
            engineRunning = false;
            btnEngineToggle.setText("▶ START ENGINE");
            btnEngineToggle.setBackgroundColor(getColor(R.color.color_green));
            tvEngineStatus.setText("ENGINE DISABLED");
            tvEngineStatus.setTextColor(getColor(R.color.color_red));
            dotEngine.setBackgroundResource(R.drawable.dot_red);
        }
    }

    private boolean requireShizuku() {
        if (!shizuku.isShizukuAvailable()) {
            showShizukuGuide();
            return false;
        }
        if (!shizuku.hasPermission()) {
            shizuku.requestPermission();
            return false;
        }
        return true;
    }

    private void showShizukuGuide() {
        new AlertDialog.Builder(this)
            .setTitle("⚡ Shizuku Required")
            .setMessage("AIMTRIX requires Shizuku to execute system commands without root.\n\n" +
                "1. Install Shizuku from Play Store\n" +
                "2. Enable via ADB: adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh\n" +
                "3. Or use Wireless debugging (Android 11+)\n" +
                "4. Open Shizuku app and start the service\n\n" +
                "Then return to AIMTRIX.")
            .setPositiveButton("OK", null)
            .setNeutralButton("Install Shizuku", (d, w) -> {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=moe.shizuku.privileged.api")));
            })
            .show();
    }

    private void checkOverlayPermission() {
        if (config.isRogOverlayEnabled() && Settings.canDrawOverlays(this)) {
            startOverlayService();
        }
    }

    private void startOverlayService() {
        Intent intent = new Intent(this, OverlayService.class);
        startForegroundService(intent);
    }

    private void requestOverlayPermission() {
        new AlertDialog.Builder(this)
            .setTitle("Overlay Permission Required")
            .setMessage("AIMTRIX needs permission to display the ROG overlay on top of games.")
            .setPositiveButton("Grant", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, 100);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void blinkView(View view) {
        AlphaAnimation anim = new AlphaAnimation(1.0f, 0.3f);
        anim.setDuration(600);
        anim.setRepeatCount(Animation.INFINITE);
        anim.setRepeatMode(Animation.REVERSE);
        view.startAnimation(anim);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(statusReceiver,
            new IntentFilter(AimtrixEngineService.BROADCAST_STATUS),
            Context.RECEIVER_NOT_EXPORTED);
        boolean ok = shizuku.isShizukuAvailable() && shizuku.hasPermission();
        updateShizukuStatus(ok);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        shizuku.setStateListener(null);
    }
}
