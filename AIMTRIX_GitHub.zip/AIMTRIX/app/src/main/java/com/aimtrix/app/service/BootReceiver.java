package com.aimtrix.app.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aimtrix.app.engine.EngineConfig;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            EngineConfig config = new EngineConfig(context);
            if (config.isAutoGameModeEnabled()) {
                Intent serviceIntent = new Intent(context, AimtrixEngineService.class);
                serviceIntent.setAction(AimtrixEngineService.ACTION_START);
                context.startForegroundService(serviceIntent);
            }
        }
    }
}
