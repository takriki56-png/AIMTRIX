package com.aimtrix.app.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.aimtrix.app.AimtrixApp;
import com.aimtrix.app.R;
import com.aimtrix.app.ui.MainActivity;

public class OverlayService extends Service {

    private static final int NOTIF_ID = 2001;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams params;

    private TextView tvFps, tvDpi, tvWm, tvEngine, tvGame;
    private View dotIndicator;

    private float initialX, initialY, initialTouchX, initialTouchY;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean shizukuOk = intent.getBooleanExtra(AimtrixEngineService.EXTRA_SHIZUKU_OK, false);
            boolean gameDetected = intent.getBooleanExtra(AimtrixEngineService.EXTRA_GAME_DETECTED, false);
            int fps = intent.getIntExtra(AimtrixEngineService.EXTRA_FPS, 60);
            updateOverlayData(fps, shizukuOk, gameDetected);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
        registerReceiver(statusReceiver,
            new IntentFilter(AimtrixEngineService.BROADCAST_STATUS),
            Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());
        return START_STICKY;
    }

    private void createOverlay() {
        LayoutInflater inflater = LayoutInflater.from(this);
        overlayView = inflater.inflate(R.layout.overlay_rog, null);

        tvFps = overlayView.findViewById(R.id.overlay_fps);
        tvDpi = overlayView.findViewById(R.id.overlay_dpi);
        tvWm = overlayView.findViewById(R.id.overlay_wm);
        tvEngine = overlayView.findViewById(R.id.overlay_engine);
        tvGame = overlayView.findViewById(R.id.overlay_game);
        dotIndicator = overlayView.findViewById(R.id.overlay_dot);

        int layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20;
        params.y = 150;

        overlayView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = (int)(initialX + event.getRawX() - initialTouchX);
                    params.y = (int)(initialY + event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(overlayView, params);
                    return true;
            }
            return false;
        });

        windowManager.addView(overlayView, params);
    }

    private void updateOverlayData(int fps, boolean shizukuOk, boolean gameDetected) {
        if (tvFps == null) return;

        tvFps.setText(fps + " FPS");
        tvDpi.setText("DPI: ADAPTIVE");
        tvWm.setText("WM: 1440x3200");
        tvEngine.setText(shizukuOk ? "ENGINE: ON" : "ENGINE: OFF");
        tvGame.setText(gameDetected ? "FF: DETECTED" : "FF: IDLE");

        int color = shizukuOk ? Color.parseColor("#00FF41") : Color.parseColor("#FF4444");
        dotIndicator.setBackgroundColor(color);
        tvEngine.setTextColor(color);

        int fpsColor = fps >= 58 ? Color.parseColor("#00FF41") 
                     : fps >= 45 ? Color.parseColor("#FFB300") 
                     : Color.parseColor("#FF4444");
        tvFps.setTextColor(fpsColor);
    }

    private Notification buildNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, AimtrixApp.CHANNEL_OVERLAY)
            .setContentTitle("AIMTRIX Overlay Active")
            .setContentText("ROG monitoring overlay is running")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pi)
            .setColor(0xFF00FF41)
            .build();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(statusReceiver);
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
            overlayView = null;
        }
    }
}
