# ⚡ AIMTRIX — Gaming Optimizer via Shizuku

> **No Root Required** | Android 11–16 | Free Fire Optimized

---

## 🎮 Features

| Feature | Command | Description |
|---|---|---|
| **Smart DPI** | `wm size 1440x3200` + `wm density adaptive` | Max resolution engine |
| **FPS Boost** | `debug.sf.latch_unsignaled=1` | SurfaceFlinger unlock |
| **Surface Tuning** | `debug.sf.disable_backpressure=1` | GPU pipeline |
| **Sensitivity Engine** | `touch.pressure.scale` + `ro.input.resample` | Aim stabilizer |
| **Cache Flush** | `am kill-all` + `sync` | RAM cleaner |
| **ROG Overlay** | Floating SYSTEM_ALERT_WINDOW | Real-time stats |
| **Game Detection** | `pidof com.dts.freefireth` | Auto FF detect |
| **VIP Mode** | Priority settings | Locked config |
| **Auto Game Start** | Background monitor | Auto-optimize |
| **Performance Graph** | Live FPS chart | Monitoring |

---

## 🔧 Build Instructions

### Prerequisites
- Android Studio Hedgehog or newer
- JDK 17+
- Android SDK 34
- Gradle 8.2

### Steps
```bash
# 1. Clone / extract project
cd AIMTRIX

# 2. Set SDK path in local.properties
echo "sdk.dir=/your/android/sdk" > local.properties

# 3. Build debug APK
./gradlew assembleDebug

# 4. Install
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 📱 Shizuku Setup

**Option 1 - Wireless Debugging (Android 11+):**
```
Settings → Developer Options → Wireless Debugging → Enable
Open Shizuku app → Start via Wireless Debugging
```

**Option 2 - ADB:**
```bash
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```

---

## 🏗️ Project Structure

```
AIMTRIX/
├── app/src/main/
│   ├── java/com/aimtrix/app/
│   │   ├── AimtrixApp.java              # Application class
│   │   ├── ui/MainActivity.java         # Main UI
│   │   ├── engine/
│   │   │   ├── GamingOptimizer.java     # Core optimization logic
│   │   │   └── EngineConfig.java        # SharedPreferences config
│   │   ├── shizuku/
│   │   │   └── ShizukuManager.java      # Shizuku bridge
│   │   └── service/
│   │       ├── AimtrixEngineService.java # Background engine
│   │       ├── OverlayService.java       # ROG overlay
│   │       └── BootReceiver.java         # Boot persistence
│   └── res/
│       ├── layout/
│       │   ├── activity_main.xml         # Dark gaming UI
│       │   └── overlay_rog.xml           # Floating overlay
│       ├── values/
│       │   ├── colors.xml
│       │   ├── strings.xml
│       │   └── themes.xml
│       └── drawable/                     # Icons & shapes
└── build.gradle
```

---

## ⚡ Commands Executed via Shizuku

```bash
# Smart DPI
wm size 1440x3200
wm density adaptive

# FPS Boost
service call SurfaceFlinger 1008 i32 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop persist.sys.ui.hw 1

# Sensitivity Engine
setprop touch.pressure.scale 0.001
setprop ro.input.resample false
setprop ro.input.noresample 1

# Cache Flush
am kill-all
sync
echo 3 > /proc/sys/vm/drop_caches

# Game Detection
pidof com.dts.freefireth
```

---

## 🔒 Security
- ✅ Zero root required
- ✅ All commands via Shizuku API
- ✅ No shell exploit or privilege escalation
- ✅ Reverts settings on engine stop

---

## 📋 Permissions Required
| Permission | Purpose |
|---|---|
| `SYSTEM_ALERT_WINDOW` | ROG overlay display |
| `FOREGROUND_SERVICE` | Background engine |
| `RECEIVE_BOOT_COMPLETED` | Auto-start on boot |
| `moe.shizuku.manager.permission.API_V23` | Shizuku API access |

---

*AIMTRIX v1.0 — Powered by Shizuku*
